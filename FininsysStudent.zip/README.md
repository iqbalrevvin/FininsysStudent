# Fininsys
Financial &amp; Information System<hr>
<b>Bulid By</b><br>
Framework : Codeigniter V3<br>
Library : GroceryCRUD, Ion Auth, OutputView, Menu Management<br>
Template : Metronic View6<hr>
<img src="https://raw.githubusercontent.com/iqbalrevvin/Fininsys/master/screenshoot/loginView.png" alt="Login View">
