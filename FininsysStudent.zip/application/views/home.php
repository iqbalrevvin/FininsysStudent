<div class="row">
    <div class="col-lg-12 col-xl-7">
        <?php require('homeSlide.php') ?>
        <?php require('homeNilai.php') ?>
    </div>

	<div class="col-xl-5 col-lg-12 mb-4">
	    <?php require('homeIdentitas.php') ?>
	</div>
</div>
