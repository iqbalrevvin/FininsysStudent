<div class="error-page">
  <h2 class="headline text-yellow"> 404</h2>
  <div class="error-content" style="padding-top:20px">
    <h3><i class="fa fa-warning text-yellow"></i> Oops! Halaman Yang Anda Tuju Tidak Ditemukan.</h3>
    <p>
      Periksa Kembali URL Tujuan Anda !!!<br>
      Kembali Ke <a href="<?php echo site_url('') ?>">Beranda</a>
    </p>
  </div><!-- /.error-content -->
</div>