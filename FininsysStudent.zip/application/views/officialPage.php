<style type="text/css" media="screen">
	.iframe-container {
    	position: relative;
    	overflow: hidden;
    	padding-top: 56.25%;
	}

	.iframe-container iframe {
  		position: absolute;
    	top: 0;
    	left: 0;
    	width: 100%;
    	height: 100%;
    	border: 0;
	}
</style>				



	<iframe width="100%" height="500" src="http://smpplus.rasanarasyidah.sch.id/"></iframe>
