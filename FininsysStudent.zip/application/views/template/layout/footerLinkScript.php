<script src="<?= base_url('assets/js/vendor/jquery-3.3.1.min.js') ?>"></script>
<script src="<?= base_url('assets/js/vendor/datatables.min.js') ?>"></script>
<!-- VENDOR/PLUGIN -->
<script src="<?= base_url('assets/js/vendor/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= base_url('assets/js/vendor/perfect-scrollbar.min.js') ?>"></script>
<script src="<?= base_url('assets/js/vendor/mousetrap.min.js') ?>"></script>

<script src="<?= base_url('assets/js/vendor/owl.carousel.min.js') ?>"></script>
<script src="<?= base_url('assets/js/vendor/select2.full.js') ?>"></script>

<!-- ////////////////////////////////////////////////////////////////////// -->


<script src="<?= base_url('assets/js/dore.script.js') ?>"></script>
<script src="<?= base_url('assets/js/scripts.single.theme.js') ?>"></script>

<script>
	$('#table').DataTable( {
    	scrollY: true,

	});
</script>