 <div class="main-menu">
    <div class="scroll">
        <ul class="list-unstyled">
            <li class="active">
                <a href="#start">
                    <i class="simple-icon-menu"></i>
                    <span>Menu</span>
                </a>
            </li>
        </ul>
    </div>
</div>
<div class="sub-menu">
    <div class="scroll">
        <ul class="list-unstyled" data-link="start">
            <li class="active">
                <a href="<?= base_url() ?>">
                    <i class="simple-icon-home"></i> Beranda
                </a>
            </li>
            <li class="active">
                <a href="<?= base_url('Home/OfficialPage') ?>">
                    <i class="iconsmind-URL-Window"></i> Website Resmi
                </a>
            </li>
        </ul>
    </div>
</div>