 <div class="sidebar">
   <?php require('menuNavigator.php') ?>
</div>