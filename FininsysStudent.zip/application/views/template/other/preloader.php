<div id="preloader" class="m-page--loading-enabled m-page--loading">
    <!--<div class="text">
        <tr>
            <td style="vertical-align:middle; width: 30%">
                Memuat Halaman. . .<br>
            </td>
        <tr>
            <td style="vertical-align:middle;">
                <div class="m-spinner m-spinner--brand m-spinner--sm"></div>
                <div class="m-spinner m-spinner--primary m-spinner--sm"></div>
                <div class="m-spinner m-spinner--success m-spinner--sm"></div>
                <div class="m-spinner m-spinner--info m-spinner--sm"></div>
                <div class="m-spinner m-spinner--warning m-spinner--sm"></div>
                <div class="m-spinner m-spinner--danger m-spinner--sm"></div>
            </td>
        </tr>
    </div>-->

    <div class="m-page-loader m-page-loader--base">
        <div class="m-blockui">
            <span>Memuat Data. . .</span>
            <span>
                <div class="m-loader m-loader--brand"></div>
            </span>
        </div>
    </div>
</div>